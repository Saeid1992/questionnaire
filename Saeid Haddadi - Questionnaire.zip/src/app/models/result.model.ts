export interface Result {
  question: string;
  answer: string;
}
